<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ViewWebsite extends Model
{
    protected $fillable = [
        "col_number"
    ];
}
